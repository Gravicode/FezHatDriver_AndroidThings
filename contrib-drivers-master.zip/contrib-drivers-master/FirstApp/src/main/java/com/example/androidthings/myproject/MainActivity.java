/*
 * Copyright 2016, The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.example.androidthings.myproject;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import java.io.IOException;
import com.google.android.things.contrib.driver.fezhat.FezHat;
import com.google.android.things.contrib.driver.fezhat.Akselerasi;
import com.google.android.things.contrib.driver.fezhat.Color;
import com.google.android.things.pio.Gpio;
import com.google.android.things.pio.PeripheralManagerService;

import java.text.DecimalFormat;
/**
 * Skeleton of the main Android Things activity. Implement your device's logic
 * in this class.
 *
 * Android Things peripheral APIs are accessible through the class
 * PeripheralManagerService. For example, the snippet below will open a GPIO pin and
 * set it to HIGH:
 *
 * <pre>{@code
 * PeripheralManagerService service = new PeripheralManagerService();
 * mLedGpio = service.openGpio("BCM6");
 * mLedGpio.setDirection(Gpio.DIRECTION_OUT_INITIALLY_LOW);
 * mLedGpio.setValue(true);
 * }</pre>
 *
 * For more complex peripherals, look for an existing user-space driver, or implement one if none
 * is available.
 *
 */
public class MainActivity extends Activity {
    private static final String TAG = MainActivity.class.getSimpleName();

    private static final int INTERVAL_BETWEEN_BLINKS_MS = 1000;

    private Handler mHandler = new Handler();

    private FezHat hat;
    private boolean next;
    private int i;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        try {
            PeripheralManagerService service = new PeripheralManagerService();
            Log.d(TAG, "Available GPIO: " + service.getGpioList());
            Log.d(TAG, "onCreate");
            Setup();
            mHandler.post(mBlinkRunnable);
        } catch (IOException e) {
            Log.d(TAG, e.getMessage());
        }

    }

    protected void Setup() throws IOException {
        this.hat = FezHat.Create();
        this.hat.S1.SetLimits(500, 2400, 0, 180);
        this.hat.S2.SetLimits(500, 2400, 0, 180);

    }


    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.d(TAG, "onDestroy");
        mHandler.removeCallbacks(mBlinkRunnable);

    }

    protected Runnable mBlinkRunnable = new Runnable() {

        @Override
        public void run() {
            try {
                mHandler.postDelayed(mBlinkRunnable, INTERVAL_BETWEEN_BLINKS_MS);
                DecimalFormat formatter = new DecimalFormat("######.000");
                Akselerasi accel = hat.GetAcceleration();
                String lightStr = formatter.format(hat.GetLightLevel());
                String Temp = formatter.format(hat.GetTemperature());
                String AccelStr = "X:" + String.valueOf(accel.X) + " Y: " + String.valueOf(accel.Y) + " Z:" + String.valueOf(accel.Z);
                String Btn18Str = String.valueOf(hat.IsDIO18Pressed());
                String Btn22Str = String.valueOf(hat.IsDIO22Pressed());
                String AnalogStr = String.valueOf(hat.ReadAnalog(FezHat.AnalogPin.Ain1));
                Log.e(TAG, "Light:"+lightStr);
                Log.e(TAG, "Temp:"+Temp);
                Log.e(TAG, "Acceleration:"+AccelStr);
                Log.e(TAG, "Counter:"+i);
                Log.e(TAG, "Next:"+next);

                if ((i++ % 5) == 0) {
                    String LedsTextBox = String.valueOf(next);

                    hat.setDIO24On(next);
                    hat.D2.setColor(next ? Color.White() : Color.Black());
                    hat.D3.setColor(next ? Color.White() : Color.Black());

                    hat.WriteDigital(FezHat.DigitalPin.DIO16, next);
                    hat.WriteDigital(FezHat.DigitalPin.DIO26, next);

                    hat.SetPwmDutyCycle(FezHat.PwmPin.Pwm5, next ? 1.0 : 0.0);
                    hat.SetPwmDutyCycle(FezHat.PwmPin.Pwm6, next ? 1.0 : 0.0);
                    hat.SetPwmDutyCycle(FezHat.PwmPin.Pwm7, next ? 1.0 : 0.0);
                    hat.SetPwmDutyCycle(FezHat.PwmPin.Pwm11, next ? 1.0 : 0.0);
                    hat.SetPwmDutyCycle(FezHat.PwmPin.Pwm12, next ? 1.0 : 0.0);

                    next = !next;
                }

                if (hat.IsDIO18Pressed()) {
                    hat.S1.setPosition(hat.S1.getPosition() + 5.0);
                    hat.S2.setPosition(hat.S2.getPosition() + 5.0);

                    if (hat.S1.getPosition() >= 180.0) {
                        hat.S1.setPosition(0.0);
                        hat.S2.setPosition(0.0);
                    }
                }

                if (hat.IsDIO22Pressed()) {
                    if (hat.MotorA.getSpeed() == 0.0) {
                        hat.MotorA.setSpeed(0.5);
                        hat.MotorB.setSpeed(-0.7);
                    }
                } else {
                    if (hat.MotorA.getSpeed() != 0.0) {
                        hat.MotorA.setSpeed(0.0);
                        hat.MotorB.setSpeed(0.0);
                    }
                }


                Log.d(TAG, "jalan lagi...");
            } catch (IOException e) {
                Log.e(TAG, "Error on Jalan", e);

            }
        }
    };
}
