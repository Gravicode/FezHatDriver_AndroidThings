package com.example.androidthings.myproject;

/**
 * Created by mifmasterz on 12/30/16.
 */

public class SensorData {
    public double Temp;
    public double Light;
    public String Accelleration;
}
