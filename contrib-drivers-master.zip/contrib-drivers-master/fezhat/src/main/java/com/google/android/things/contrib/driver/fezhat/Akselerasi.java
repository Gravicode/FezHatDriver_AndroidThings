package com.google.android.things.contrib.driver.fezhat;

/**
 * Created by mifmasterz on 12/29/16.
 */

public class Akselerasi{
    public double X;
    public double Y;
    public double Z;
}